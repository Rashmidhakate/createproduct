<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

// @codingStandardsIgnoreFile

namespace CP\Createproduct\Model;


class Import extends \Magento\ImportExport\Model\AbstractModel
{
    const ENABLE_PRODUCT_CREATE_AUTOMATICALLY = 'product_is_active';
}
