<?php
namespace CP\Createproduct\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class UpgradeSchema implements  UpgradeSchemaInterface
{

	public function upgrade(
		SchemaSetupInterface $setup,
		ModuleContextInterface $context
	)
	{
		$setup->startSetup();
		if (version_compare($context->getVersion(), '2.0.1') < 0) {
			$tableName = $setup->getTable('importexport_importdata');
			// Check if the table already exists
			if ($setup->getConnection()->isTableExists($tableName) == true) {
				$columns = [
					'product_is_active' => [
					'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
					'nullable' => true,
					'comment' => 'enable_product_create_automatically',
					],
				];
				$connection = $setup->getConnection();
				foreach ($columns as $name => $definition) {
					$connection->addColumn($tableName, $name, $definition);
				}		 
			}
		} 
		$setup->endSetup();
	}
}