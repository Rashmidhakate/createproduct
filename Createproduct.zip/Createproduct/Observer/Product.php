<?php 
namespace CP\Createproduct\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class Product implements ObserverInterface
{
	public function __construct(
        \Magento\Framework\App\RequestInterface $request
    ) {
        $this->_request = $request;
    }
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
		$adapter = $observer->getEvent()->getBunch();
		$productSku = $adapter[0]['sku'];
		$categories = $adapter[0]['categories'];
		$category_array = explode('/', $categories);
		$category_name = $category_array[3];
		$sku_array = explode('-',trim($productSku));
		$prefix_product_sku = $sku_array[0];
		$FreeSampleNewSku = $prefix_product_sku.'-SDOOR';
		$FullDoorNewSku = $prefix_product_sku.'-SDOOR-FULL';

		/* create product */
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // instance of object manager
		$product = $objectManager->create('Magento\Catalog\Model\Product');
		$productCollection = $objectManager->create('Magento\Catalog\Model\ResourceModel\Product\CollectionFactory');
		$collection = $productCollection->create()
            ->addAttributeToSelect('sku')
            ->load();
		$productSku = array();
		foreach ($collection as $products) {
			$productSku[] = $products->getSku();
		}

		if($this->_request->getParam("product_is_active") == 1){
			// Check newSKu for product is available or not in product collection
			if(!in_array($FreeSampleNewSku,$productSku) && !in_array($FullDoorNewSku,$productSku)){
				$product->setSku($FreeSampleNewSku); // Set your sku here
				$product->setName($category_name); // Name of Product
				$product->setAttributeSetId(4); // Attribute set id
				$product->setStatus(1); // Status on product enabled/ disabled 1/0
				$product->setWeight(8); // weight of product
				$product->setVisibility(4); // visibilty of product (catalog / search / catalog, search / Not visible individually)
				$product->setTaxClassId(0); // Tax class id
				$product->setTypeId('simple'); // type of product (simple/virtual/downloadable/configurable)
				$product->setUrlKey($this->generateUrl($category_name));
				$product->setWebsiteIds([1]);
				$product->setPrice(0); // price of product
				$product->setStockData(
				            array(
				                'use_config_manage_stock' => 0,
				                'manage_stock' => 1,
				                'is_in_stock' => 1,
				                'qty' => 1000
				            )
				        );
				$product->setCategoryIds([20,21]);
				$product->save();

				$product_full = $objectManager->create('Magento\Catalog\Model\Product');
				$product_full->setSku($FullDoorNewSku); // Set your sku here
				$product_full->setName($category_name); // Name of Product
				$product_full->setAttributeSetId(4); // Attribute set id
				$product_full->setStatus(1); // Status on product enabled/ disabled 1/0
				$product_full->setWeight(10); // weight of product
				$product_full->setVisibility(4); // visibilty of product (catalog / search / catalog, search / Not visible individually)
				$product_full->setTaxClassId(0); // Tax class id
				$product_full->setTypeId('simple'); // type of product (simple/virtual/downloadable/configurable)
				$product_full->setUrlKey($this->generateUrl($category_name).'-full');
				$product_full->setPrice(25); // price of product
				$product_full->setSpecialPrice(20); 
				$product_full->setSpecialFromDate(date('m/d/y')); 
				$product_full->setWebsiteIds([1]);
				$product_full->setStockData(
				        array(
				            'use_config_manage_stock' => 0,
				            'manage_stock' => 1,
				            'is_in_stock' => 1,
				            'qty' => 1000
				        )
				    );
				$product_full->setCategoryIds([20,21]);
				$product_full->save();
			}
		}
		
		/* @end Product code */
    }
    public function generateUrl($url)
    {
        $url = preg_replace('~[^\\pL\d]+~u', '-', $url);
        // trim
        $url = trim($url, '-');
         // transliterate
        if (function_exists('iconv'))
        {
            $url = iconv('utf-8', 'us-ascii//TRANSLIT', $url);
        }
        // lowercase
        $url = strtolower($url);
        // remove unwanted characters
        $url = preg_replace('~[^-\w]+~', '', $url);
        return $url;
    }
}

