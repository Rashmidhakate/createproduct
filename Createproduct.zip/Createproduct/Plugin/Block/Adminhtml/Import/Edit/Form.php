<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace CP\Createproduct\Plugin\Block\Adminhtml\Import\Edit;

use Magento\ImportExport\Model\Import;
use Magento\ImportExport\Model\Import\ErrorProcessing\ProcessingErrorAggregatorInterface;

/**
 * Import edit form block
 *
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Form 
{

    public function __construct(
        \CP\Createproduct\Model\Source\Product $requestProduct
    ) {
        $this->requestProduct = $requestProduct;
    }
      /**
     * Get form HTML
     *
     * @return string
     */
    public function aroundGetFormHtml(
        \Magento\ImportExport\Block\Adminhtml\Import\Edit\Form $subject,
        \Closure $proceed
    )
    {
        $form = $subject->getForm();
        if (is_object($form)) {
            $fieldset = $form->addFieldset('admin_product_is_active', ['legend' => __('Product Create Automatically')]);
            $fieldset->addField(
                'product_is_active',
                'select',
                [
                    'label' => __('Status'),
                    'title' => __('Status'),
                    'name' => 'product_is_active',
                    'required' => false,
                    'values' => $this->requestProduct->toOptionArray()
                ]
            );

            $subject->setForm($form);
        }

        return $proceed();
    }
}
